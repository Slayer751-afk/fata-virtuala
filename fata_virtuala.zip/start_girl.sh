#!/bin/bash
cd "$(dirname "$0")"
python3 fata_virtuala_unificata.py
